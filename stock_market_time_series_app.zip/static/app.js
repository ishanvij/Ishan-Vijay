document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('analyze-form');
  const plotArea = document.getElementById('plot-area');
  const modelSummary = document.getElementById('model-summary');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    plotArea.innerHTML = 'Loading...';
    modelSummary.textContent = '';
    const formData = new FormData(form);
    try {
      const resp = await fetch('/analyze', { method: 'POST', body: formData });
      const data = await resp.json();
      if (data.status !== 'ok') {
        plotArea.innerHTML = `<div style="color:red">${data.message || 'Unknown error'}</div>`;
        return;
      }
      plotArea.innerHTML = data.plot_html || '<div>No plot generated</div>';
      modelSummary.textContent = data.model_summary || '';
    } catch (err) {
      console.error(err);
      plotArea.innerHTML = `<div style="color:red">Error: ${err.message}</div>`;
    }
  });
});