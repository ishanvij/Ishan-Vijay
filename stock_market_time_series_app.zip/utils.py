import yfinance as yf
import pandas as pd
from pmdarima import auto_arima
from statsmodels.tsa.statespace.sarimax import SARIMAX
import plotly.graph_objs as go
import plotly.io as pio
from joblib import Memory
import os

CACHE_DIR = os.path.join('.', 'cache')
memory = Memory(CACHE_DIR, verbose=0)

@memory.cache
def fetch_data(symbol: str, start: str, end: str, interval: str = '1d'):
    try:
        ticker = yf.Ticker(symbol)
        df = ticker.history(start=start, end=end, interval=interval, auto_adjust=False)
        if df.empty:
            return df
        df = df.reset_index()
        df = df[['Date', 'Open', 'High', 'Low', 'Close', 'Volume']]
        df['Date'] = pd.to_datetime(df['Date'])
        df = df.set_index('Date')
        return df
    except Exception:
        return pd.DataFrame()

def fit_auto_arima(series, seasonal=False, m=1):
    model = auto_arima(series, seasonal=seasonal, m=m, stepwise=True, suppress_warnings=True, error_action='ignore', trace=False)
    return model

def fit_sarimax(series, order=(1,1,1), seasonal_order=(0,0,0,0)):
    mod = SARIMAX(series, order=order, seasonal_order=seasonal_order, enforce_stationarity=False, enforce_invertibility=False)
    res = mod.fit(disp=False)
    return res

def analyze_and_forecast(df, periods=30):
    result = {}
    series = df['Close'].asfreq('D').fillna(method='ffill')
    try:
        arima_model = fit_auto_arima(series, seasonal=False)
        fcst, conf_int = arima_model.predict(n_periods=periods, return_conf_int=True, alpha=0.05)
        index = pd.date_range(start=series.index[-1] + pd.Timedelta(days=1), periods=periods, freq='D')
        forecast_df = pd.DataFrame({'ds': index, 'yhat': fcst, 'yhat_lower': conf_int[:,0], 'yhat_upper': conf_int[:,1]}).set_index('ds')
        result['method'] = 'pmdarima_auto_arima'
        result['forecast'] = forecast_df
        result['model_summary'] = str(arima_model.summary())
    except Exception as e:
        try:
            sarimax_res = fit_sarimax(series)
            pred = sarimax_res.get_forecast(steps=periods)
            mean = pred.predicted_mean
            ci = pred.conf_int()
            index = pd.date_range(start=series.index[-1] + pd.Timedelta(days=1), periods=periods, freq='D')
            forecast_df = pd.DataFrame({'ds': index, 'yhat': mean.values, 'yhat_lower': ci.iloc[:,0].values, 'yhat_upper': ci.iloc[:,1].values}).set_index('ds')
            result['method'] = 'sarimax'
            result['forecast'] = forecast_df
            result['model_summary'] = str(sarimax_res.summary())
        except Exception as e2:
            result['method'] = 'none'
            result['forecast'] = pd.DataFrame()
            result['model_summary'] = f'Both model fits failed: {e2}'

    if not result['forecast'].empty:
        result['forecast_table'] = result['forecast'][['yhat','yhat_lower','yhat_upper']].round(2)
    return result

def make_interactive_plot(df, fcst_result):
    pio.templates.default = "plotly"
    hist = df['Close'].reset_index()
    hist_trace = go.Scatter(x=hist['Date'], y=hist['Close'], mode='lines', name='Close')
    data = [hist_trace]
    if 'forecast' in fcst_result and not fcst_result['forecast'].empty:
        fcst = fcst_result['forecast'].reset_index()
        trace_fcst = go.Scatter(x=fcst['ds'], y=fcst['yhat'], mode='lines', name='Forecast')
        ci = go.Scatter(
            x=list(fcst['ds']) + list(fcst['ds'][::-1]),
            y=list(fcst['yhat_upper']) + list(fcst['yhat_lower'][::-1]),
            fill='toself',
            fillcolor='rgba(0,100,80,0.15)',
            line=dict(color='rgba(255,255,255,0)'),
            hoverinfo="skip",
            name='95% CI',
        )
        data += [trace_fcst, ci]
    layout = go.Layout(title='Price & Forecast', xaxis=dict(title='Date'), yaxis=dict(title='Price'))
    fig = go.Figure(data=data, layout=layout)
    return pio.to_html(fig, full_html=False, include_plotlyjs='cdn')
