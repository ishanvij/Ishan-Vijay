from flask import Flask, render_template, request, jsonify
import datetime
from utils import fetch_data, analyze_and_forecast, make_interactive_plot
import traceback

app = Flask(__name__)

@app.route('/')
def index():
    today = datetime.date.today()
    default_start = today - datetime.timedelta(days=365*2)
    return render_template('index.html', default_ticker='AAPL', start=default_start.isoformat(), end=today.isoformat())

@app.route('/analyze', methods=['POST'])
def analyze():
    try:
        data = request.form
        symbol = data.get('symbol', 'AAPL').upper().strip()
        start = data.get('start')
        end = data.get('end')
        freq = data.get('freq', 'D')
        forecast_periods = int(data.get('periods', 30))

        df = fetch_data(symbol, start, end, interval=freq)
        if df is None or df.empty:
            return jsonify({'status': 'error', 'message': f'No data for {symbol}'}), 404

        fcst_result = analyze_and_forecast(df, periods=forecast_periods)
        price_plot = make_interactive_plot(df, fcst_result)

        response = {
            'status': 'ok',
            'symbol': symbol,
            'plot_html': price_plot,
            'model_summary': fcst_result.get('model_summary', ''),
            'forecast_table': fcst_result.get('forecast_table', []).tolist() if 'forecast_table' in fcst_result else []
        }
        return jsonify(response)
    except Exception as e:
        traceback.print_exc()
        return jsonify({'status': 'error', 'message': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000, debug=True)
